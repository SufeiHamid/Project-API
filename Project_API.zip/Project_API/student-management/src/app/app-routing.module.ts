import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddStudentComponent } from './components/add-student/add-student.component';
import { EditStudentComponent } from './components/edit-student/edit-student.component';
import { ListStudentComponent } from './components/list-student/list-student.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { AboutComponent } from './components/about/about.component';
import { FAQComponent } from './components/faq/faq.component';


const routes: Routes = [
  {
    path:'about',
    component: AboutComponent
  },
  {
    path:'add',
    component: AddStudentComponent
  },
  {
    path:'edit/:id',
    component: EditStudentComponent
  },
  {
    path:'list',
    component: ListStudentComponent
  },
  {
    path:'', redirectTo:'login', pathMatch:'full'
  },
  {
    path:'FAQ',
    component: FAQComponent
  },
  {
    path:'login', 
    component: LoginComponent
  },
  {
    path:'register', 
    component: SignupComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
